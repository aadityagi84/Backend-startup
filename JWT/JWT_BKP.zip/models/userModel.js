const mongoose = require("mongoose");

const Schema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
  },
  mobile: {
    required: true,
    type: String,
  },
  password: {
    required: true,
    type: String,
  },
  is_verified: {
    type: Number,
    default: 0, // 1 will be shown when user will be verified ,
  },
  image: {
    type: String,
    required: true,
  },
});

module.exports = mongoose.model("user", Schema);
