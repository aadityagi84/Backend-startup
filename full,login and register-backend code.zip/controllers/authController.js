const { hashPass, comparePassword } = require("../helpers/authHelper");
const users = require("../models/UserModel");
const JWT = require("jsonwebtoken");

const registerController = async (req, res) => {
  try {
    const { name, email, address, phone, password } = req.body;

    // Log to check request body
    console.log(req.body);

    // Validations
    if (!name) {
      return res.status(400).send({ error: "Name is required" });
    }
    if (!email) {
      return res.status(400).send({ error: "Email is required" });
    }
    if (!address) {
      return res.status(400).send({ error: "Address is required" });
    }
    if (!phone) {
      return res.status(400).send({ error: "Phone is required" });
    }
    if (!password) {
      return res.status(400).send({ error: "Password is required" });
    }

    // Hash password and save the user as before
    const hashedPassword = await hashPass(password);
    const usermodel = new users({
      name,
      email,
      address,
      phone,
      password: hashedPassword,
    });

    await usermodel.save();
    return res.status(201).send({
      success: true,
      message: "User registered successfully",
      user: usermodel,
    });
  } catch (error) {
    console.log("Error in registerController:", error);
    res.status(500).json({
      success: false,
      message: "Error in registration",
      error,
    });
  }
};

// method POST But USing in Login

const loginController = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res
        .status(404)
        .send({ success: false, message: "invalid  user credential " });
    }

    // to decrypt the password which will be save in database
    const user = await users.findOne({ email });
    if (!user) {
      return res.status(404).send({
        success: false,
        message: "Email is not Registerd",
      });
    }
    const match = await comparePassword(password, user.password);
    if (!match) {
      return res.status(200).send({
        success: false,
        message: "invalid password ",
      });
    }

    // if the all over condtion will work correctly then crete a token
    const token = await JWT.sign({ _id: user._id }, process.env.JWT_SECRET, {
      expiresIn: "5d",
    });

    res.status(200).send({
      success: true,
      message: "login Successfully ",
      user: {
        name: user.name,
        email: user.email,
        phone: user.phone,
        adress: user.address,
      },
      token,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: " login faild",
      error,
    });
  }
};
module.exports = { registerController, loginController };
