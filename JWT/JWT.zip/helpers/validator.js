const { check } = require("express-validator");

exports.registerValidator = [
  check("name", "Name is required").not().isEmpty(),
  check("email", "Please include the valid email")
    .isEmail()
    .normalizeEmail({ gmail_remove_dots: true }),
  check("mobile", "Number  is required only 10 numbers").isLength({
    max: 10,
    min: 10,
  }),
  check(
    "password",
    "Password should be more than 6 digits and contain at least one uppercase letter and one lowecase letter, and one number and one special character"
  ).isStrongPassword({
    minLength: 6,
    minUppercase: 1,
    minLowercase: 1,
    minNumbers: 1,
  }),
  check("image").custom((value, { req }) => {
    if (!req.file) {
      throw new Error("No file uploaded");
    }

    // Check the file's mimetype
    const allowedMimeTypes = ["image/jpeg", "image/png", "image/jpg"];
    if (allowedMimeTypes.includes(req.file.mimetype)) {
      return true; // Valid file type
    } else {
      throw new Error(
        "Invalid file type. Only JPEG, PNG, and JPG are allowed."
      );
    }
  }),
];

exports.sendMailValidator = [
  check("email", "Please include the valid email")
    .isEmail()
    .normalizeEmail({ gmail_remove_dots: true }),
];
