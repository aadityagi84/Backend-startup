const express = require("express");
const router = express.Router();
router.use(express.json());
const path = require("path");
const { handleUserregister } = require("../controllers/userController");
const {
  registerValidator,
  sendMailValidator,
} = require("../helpers/validator");
const multer = require("multer");

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    // image validation
    if (
      file.mimetype == "image/jpeg" ||
      file.mimetype == "image/png" ||
      file.mimetype == "image/jpg"
    ) {
      cb(null, path.join(__dirname, "../public/images"));
    }
  },
  filename: function (req, file, cb) {
    const name = Date.now() + "-" + file.originalname;
    cb(null, name);
  },
});
const fileFilter = (req, file, cb) => {
  if (
    file.mimetype == "image/jpeg" ||
    file.mimetype == "image/png" ||
    file.mimetype == "image/jpg"
  ) {
    cb(null, true);
  } else {
    cb(null, false);
  }
};
const upload = multer({ storage: storage, fileFilter: fileFilter });

router.post(
  "/register",
  upload.single("image"),
  registerValidator,
  handleUserregister
);

router.post("/send-mail-verification", sendMailValidator);
module.exports = router;
