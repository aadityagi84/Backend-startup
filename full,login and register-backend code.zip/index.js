const express = require("express");
require("dotenv").config();
const app = express();
// for using the color property in terminal
const color = require("colors");
const morgan = require("morgan");
const connectDB = require("./config/db");
const authRoutes = require("./routes/authRoute");

const PORT = process.env.PORT || 8000;

// middlewares
app.use(express.json());
app.use(morgan("dev"));

// database calling
connectDB();

// all routes
app.use("/api/v1/auth", authRoutes);

app.get("/", (req, res) => {
  res.send("<h1>Hello this is backend word</h1>");
});
app.listen(PORT, () => [
  console.log(
    `server will be setuped on http://localhost:${PORT}`.bgCyan.white
  ),
]);
