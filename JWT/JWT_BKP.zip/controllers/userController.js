const User = require("../models/userModel"); // Corrected the model name to uppercase for better naming convention
const bcrypt = require("bcrypt");
const { validationResult } = require("express-validator"); // Fixed the typo (valatdtionResult -> validationResult)
const { sendMail } = require("../helpers/Mailer"); // Correctly import sendMail

async function handleUserregister(req, res) {
  try {
    // Validate the request using express-validator
    const errors = validationResult(req); // Fixed typo

    if (!errors.isEmpty()) {
      // If there are validation errors, send them in the response
      return res
        .status(400)
        .json({ success: false, msg: "Errors", errors: errors.array() });
    }

    // Destructure request body to get the required fields
    const { name, email, mobile, password } = req.body;

    // Check if a user with the same email already exists
    const isExists = await User.findOne({ email }); // Changed 'user' to 'User' to avoid confusion
    if (isExists) {
      return res.status(400).json({
        success: false,
        msg: "Email already exists",
      });
    }

    // Hash the password using bcrypt with a salt of 10 rounds
    const hashPassword = await bcrypt.hash(password, 10);

    // Check if the image is uploaded, otherwise handle the missing file
    let imagePath = "";
    if (req.file && req.file.filename) {
      imagePath = "images/" + req.file.filename; // Generate the image path
    } else {
      // Handle case when no image is uploaded
      return res.status(400).json({
        success: false,
        msg: "Image file is required",
      });
    }

    // Create a new user instance and save it to the database
    const newUser = new User({
      name,
      email,
      mobile,
      password: hashPassword,
      image: imagePath,
    });

    // Save the new user to the database
    const userData = await newUser.save();
    const msg = `<p> Hi ${name}  and your mobile no is <br>  ${userData.mobile} , Please <a href="http://localhost:8000/mail-verification?id=${userData._id}">verify your email</a>.</p>`;

    // Use sendMail directly as it is imported as a function
    try {
      const info = await sendMail(email, "Mail Verification", msg);
      console.log("Email sent:", info.response);
    } catch (error) {
      console.error("Error sending email:", error);
    }

    // Respond with success message and user data
    return res.status(200).json({
      success: true,
      msg: "Register success",
      user: userData,
    });
  } catch (err) {
    console.error(err);
    return res.status(400).json({
      success: false,
      msg: err.message, // Send the error message in the response
    });
  }
}

const mailVerification = async (req, res) => {
  try {
    if (req.query.id == undefined) {
      res.render("404");
    }

    const userDataByID = await User.findOne({ _id: req.query.id });
    if (userDataByID) {
      if (userDataByID.is_verified == 1) {
        return res.render("mail-verification", {
          message: "Your Mail has be already verified successfully!",
        });
      }
      await User.findByIdAndUpdate(
        { _id: req.query.id },
        {
          $set: { is_verified: 1 },
        }
      );
      return res.render("Complete-verification");
    } else {
      res.render("mail-verification", { message: "User not found" });
    }
  } catch (error) {
    console.log(error.message);
    res.render("404");
  }
};

const sendMailVerification = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty) {
      return res
        .status(400)
        .json({ success: false, msg: " errors", errors: errors.array() });
    }
  } catch (err) {
    console.log(error.message);
    return res.status(400).json({ success: false, msg: error.message });
  }
};

module.exports = {
  handleUserregister,
  mailVerification,
  sendMailVerification,
};
