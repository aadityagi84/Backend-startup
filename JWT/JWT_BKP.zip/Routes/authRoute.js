const express = require("express");
const router = express.Router();
router.use(express.json());

const {
  mailVerification,
  sendMailVerification,
} = require("../controllers/userController");

router.get("/mail-verification", mailVerification, sendMailVerification);
module.exports = router;
