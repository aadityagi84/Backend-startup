// helpers/Mailer.js
const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: process.env.SMTP_PORT,
  secure: false, // Set to true if using port 465
  requireTLS: true,
  auth: {
    user: process.env.SMTP_MAIL,
    pass: process.env.SMTP_PASSWORD,
  },
});

const sendMail = async (email, subject, content) => {
  try {
    if (!email) {
      throw new Error("No recipient email provided");
    }

    const mailOptions = {
      from: process.env.SMTP_MAIL,
      to: email,
      subject: subject,
      html: content,
    };

    const info = await transporter.sendMail(mailOptions);
    return info; // Return the result for chaining
  } catch (err) {
    console.error("Error sending mail:", err.message);
    throw err; // Rethrow the error
  }
};

module.exports = { sendMail }; // Export the function itself
