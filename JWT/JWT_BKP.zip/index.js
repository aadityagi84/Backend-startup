const dotEnv = require("dotenv");
dotEnv.config();
const express = require("express");
const mongoose = require("mongoose");
mongoose
  .connect("mongodb://127.0.0.1:27017/resful-auth-api")
  .then(() => console.log("databse will be setupd"))
  .catch((err) => {
    console.log(err);
  });
const app = express();
// set ejs for output
app.set("view engine", "ejs");
// set folder name
app.set("views", "./views");

//
const PORT = process.env.SERVER_PORT;
const userRoute = require("./Routes/UserRoutes");
app.use("/api", userRoute);
const authRoute = require("./Routes/authRoute");
app.use("/", authRoute);

app.listen(PORT, () => {
  console.log(`Server will be launched on http://localhost:${PORT}`);
});
